/* Run with: node tests/ocs.test.js
   Plain Node assertions \u2014 no test framework dependency added. */
const assert = require("assert");
const OCS = require("../assets/ocs.js");

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log("  \u2713 " + name);
  } catch (e) {
    failed++;
    console.log("  \u2717 " + name);
    console.log("      " + e.message);
  }
}

console.log("\nOffer Clarity Scorer \u2014 test suite\n");

/* ---------- 1. clear, well-specified offer scores high across the board ---------- */
test("clear offer: every dimension scores in Mostly Clear or above, composite >= 65", function () {
  const inputs = {
    audience: "VPs of Sales at 50\u2013200 person B2B SaaS companies doing $5M\u2013$30M ARR, selling mid-market deals.",
    problem: "Reps spend roughly 40% of their week manually updating CRM fields instead of selling, and pipeline data is too stale to trust for forecasting.",
    outcome: "Forecast accuracy improves from about 60% to 90%+ within one quarter, and reps get back 6 to 8 hours per week.",
    mechanism: "We audit your CRM fields against your real sales process, rebuild pipeline stages around actual buying signals, then train the team on stage-exit criteria.",
    differentiation: "Unlike generic RevOps consultants, we work entirely inside the CRM you already use \u2014 no new tool to adopt, no 6-month implementation.",
    value: "Flat $8,000 engagement; the average client recovers that within the first month from recovered pipeline alone.",
    proof: "Used by 40 B2B sales teams so far; one client, Meridian Analytics, cut sales cycle length by 22% in Q1 2026.",
    nextstep: "Book a 20-minute pipeline audit call using the link below \u2014 no deck or prep required on your side."
  };
  const scan = OCS.runScan(inputs);
  assert.ok(scan.composite !== null, "composite should not be null");
  assert.ok(scan.composite >= 65, "expected composite >= 65, got " + scan.composite);
  scan.results.forEach(function (r) {
    assert.ok(r.score >= 65, r.dim.label + " expected >= 65, got " + r.score);
  });
});

/* ---------- 2. vague outcome pulls that dimension down while others stay clear ---------- */
test("vague outcome: outcome dimension scores lower than a concrete sibling dimension", function () {
  const inputs = {
    audience: "VPs of Sales at 50\u2013200 person B2B SaaS companies doing $5M\u2013$30M ARR.",
    problem: "Reps spend 40% of their week manually updating CRM fields instead of selling.",
    outcome: "We help you achieve amazing, world-class results and unlock your best performance.",
    mechanism: "We audit your CRM against your sales process and rebuild the pipeline stages.",
    differentiation: "We are the best solution on the market for revenue teams.",
    value: "Great value for a fair price.",
    proof: "Trusted by many happy clients.",
    nextstep: "Reach out if interested."
  };
  const scan = OCS.runScan(inputs);
  const outcomeRow = scan.results.find(function (r) { return r.dim.id === "outcome"; });
  const audienceRow = scan.results.find(function (r) { return r.dim.id === "audience"; });
  assert.ok(outcomeRow.score < audienceRow.score, "vague outcome (" + outcomeRow.score + ") should score below the concrete audience field (" + audienceRow.score + ")");
});

/* ---------- 3. weak proof surfaces as a leak ---------- */
test("weak proof: proof/trust field with no evidence lands in the bottom-3 leaks", function () {
  const inputs = {
    audience: "VPs of Sales at 50\u2013200 person B2B SaaS companies doing $5M\u2013$30M ARR.",
    problem: "Reps spend 40% of their week manually updating CRM fields instead of selling deals.",
    outcome: "Forecast accuracy improves from 60% to 90%+ within one quarter.",
    mechanism: "We audit CRM fields, rebuild pipeline stages, and train the team on exit criteria.",
    differentiation: "Unlike generic consultants, we work inside the CRM you already use.",
    value: "Flat $8,000 engagement, recovered within the first month for most clients.",
    proof: "We are great and our clients love working with us.",
    nextstep: "Book a 20-minute pipeline audit call using the link below."
  };
  const scan = OCS.runScan(inputs);
  const leakIds = scan.leaks.map(function (r) { return r.dim.id; });
  assert.ok(leakIds.indexOf("proof") !== -1, "expected 'proof' among the top-3 leaks, got: " + leakIds.join(", "));
});

/* ---------- 4. weak CTA surfaces as the single biggest leak when everything else is strong ---------- */
test("weak CTA: vague next-step is identified as the biggest leak when all other fields are strong", function () {
  const inputs = {
    audience: "VPs of Sales at 50\u2013200 person B2B SaaS companies doing $5M\u2013$30M ARR.",
    problem: "Reps spend 40% of their week manually updating CRM fields instead of selling deals.",
    outcome: "Forecast accuracy improves from 60% to 90%+ within one quarter for most clients.",
    mechanism: "We audit CRM fields, rebuild pipeline stages, and train the team on exit criteria.",
    differentiation: "Unlike generic consultants, we work inside the CRM you already use, no new tool.",
    value: "Flat $8,000 engagement, recovered within the first month from recovered pipeline.",
    proof: "Used by 40 B2B sales teams; Meridian Analytics cut sales cycle by 22% in Q1 2026.",
    nextstep: "Let us know if you're interested and we can talk."
  };
  const scan = OCS.runScan(inputs);
  assert.strictEqual(scan.biggestLeak.dim.id, "nextstep", "expected 'nextstep' as biggest leak, got '" + scan.biggestLeak.dim.id + "'");
});

/* ---------- 5. commoditized offer: heavy generic language drags differentiation down ---------- */
test("commoditized offer: generic superlative language scores lower than specific comparative language", function () {
  const generic = OCS.analyzeText("We are the best, most innovative, world-class solution for revenue teams everywhere.");
  const specific = OCS.analyzeText("Unlike Gong or Clari, we don't require a new dashboard \u2014 we rebuild the CRM stages your reps already use every day.");
  assert.ok(generic.status === "scored" && specific.status === "scored");
  assert.ok(generic.score < specific.score, "generic (" + generic.score + ") should score below specific comparative claim (" + specific.score + ")");
});

/* ---------- 6. insufficient data is never scored or fabricated ---------- */
test("insufficient data: empty and near-empty fields are marked insufficient, not scored", function () {
  const empty = OCS.analyzeText("");
  const tooShort = OCS.analyzeText("SMBs");
  assert.strictEqual(empty.status, "insufficient");
  assert.strictEqual(tooShort.status, "insufficient");

  const scan = OCS.runScan({
    audience: "",
    problem: "founders",
    outcome: "Forecast accuracy improves from 60% to 90%+ within one quarter for most clients.",
    mechanism: "",
    differentiation: "",
    value: "",
    proof: "",
    nextstep: ""
  });
  assert.ok(scan.insufficientCount >= 5, "expected several insufficient dimensions, got " + scan.insufficientCount);
  scan.results.forEach(function (r) {
    if (r.analysis.status === "insufficient") {
      assert.strictEqual(r.score, null, r.dim.id + " should not have a fabricated score");
    }
  });
});

/* ---------- 7. score-band boundaries are exact ---------- */
test("score bands: boundaries at 85 / 65 / 40 resolve to the correct label", function () {
  assert.strictEqual(OCS.bandFor(100).label, "Crystal Clear");
  assert.strictEqual(OCS.bandFor(85).label, "Crystal Clear");
  assert.strictEqual(OCS.bandFor(84).label, "Mostly Clear");
  assert.strictEqual(OCS.bandFor(65).label, "Mostly Clear");
  assert.strictEqual(OCS.bandFor(64).label, "Foggy");
  assert.strictEqual(OCS.bandFor(40).label, "Foggy");
  assert.strictEqual(OCS.bandFor(39).label, "Leaking");
  assert.strictEqual(OCS.bandFor(0).label, "Leaking");
});

console.log("\n" + passed + " passed, " + failed + " failed\n");
process.exit(failed > 0 ? 1 : 0);
