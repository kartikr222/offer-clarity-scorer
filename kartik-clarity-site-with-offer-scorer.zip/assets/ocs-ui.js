(function () {
  "use strict";

  var OCS = window.OfferClarityScorer;
  var DIMS = OCS.DIMENSIONS;

  var els = {
    intro: document.getElementById("ocsIntro"),
    start: document.getElementById("ocsStart"),
    wizard: document.getElementById("ocsWizard"),
    steps: document.getElementById("ocsSteps"),
    form: document.getElementById("ocsForm"),
    back: document.getElementById("ocsBack"),
    skip: document.getElementById("ocsSkip"),
    next: document.getElementById("ocsNext"),
    error: document.getElementById("ocsError"),
    progress: document.getElementById("ocsProgress"),
    progressFill: document.getElementById("ocsProgressFill"),
    progressLabel: document.getElementById("ocsProgressLabel"),
    report: document.getElementById("ocsReport"),
    composite: document.getElementById("ocsComposite"),
    insufficientNote: document.getElementById("ocsInsufficientNote"),
    breakdown: document.getElementById("ocsBreakdown"),
    leak: document.getElementById("ocsLeak"),
    fixes: document.getElementById("ocsFixes"),
    restart: document.getElementById("ocsRestart"),
    methodToggle: document.getElementById("ocsMethodToggle"),
    methodDetail: document.getElementById("ocsMethodDetail")
  };

  var state = {
    current: 0,
    values: {},   // dim.id -> string
    skipped: {}   // dim.id -> bool
  };

  /* ---------- build the 8 step markup once ---------- */
  DIMS.forEach(function (dim, i) {
    var step = document.createElement("div");
    step.className = "ocs-step";
    step.dataset.index = String(i);
    if (i !== 0) step.hidden = true;

    var label = document.createElement("label");
    label.className = "ocs-q";
    label.setAttribute("for", "ocs-field-" + dim.id);
    label.textContent = dim.prompt;

    var meta = document.createElement("p");
    meta.className = "ocs-q-meta";
    meta.textContent = dim.label;

    var textarea = document.createElement("textarea");
    textarea.id = "ocs-field-" + dim.id;
    textarea.className = "ocs-textarea";
    textarea.rows = 4;
    textarea.placeholder = dim.placeholder;
    textarea.setAttribute("aria-describedby", "ocs-hint-" + dim.id);

    var hint = document.createElement("div");
    hint.className = "ocs-hint";
    hint.id = "ocs-hint-" + dim.id;
    hint.textContent = "Write a sentence or two — " + OCS.MIN_CHARS + " characters minimum.";

    textarea.addEventListener("input", function () {
      updateHint(dim.id, textarea.value);
      hideError();
    });

    step.appendChild(meta);
    step.appendChild(label);
    step.appendChild(textarea);
    step.appendChild(hint);
    els.steps.appendChild(step);
  });

  function updateHint(id, value) {
    var hint = document.getElementById("ocs-hint-" + id);
    var len = value.trim().length;
    if (len === 0) {
      hint.textContent = "Write a sentence or two — " + OCS.MIN_CHARS + " characters minimum.";
      hint.classList.remove("ocs-hint-ok");
    } else if (len < OCS.MIN_CHARS) {
      hint.textContent = len + " / " + OCS.MIN_CHARS + " characters — a little more detail will help.";
      hint.classList.remove("ocs-hint-ok");
    } else {
      hint.textContent = "Good — that's enough to score.";
      hint.classList.add("ocs-hint-ok");
    }
  }

  function showError(msg) {
    els.error.textContent = msg;
    els.error.hidden = false;
  }
  function hideError() {
    els.error.hidden = true;
  }

  /* ---------- wizard navigation ---------- */

  function goToStep(i) {
    var steps = els.steps.querySelectorAll(".ocs-step");
    steps.forEach(function (s) { s.hidden = Number(s.dataset.index) !== i; });
    state.current = i;

    els.back.disabled = i === 0;
    els.next.textContent = i === DIMS.length - 1 ? "See your score" : "Next";

    els.progress.setAttribute("aria-valuenow", String(i + 1));
    els.progressLabel.textContent = "Question " + (i + 1) + " of " + DIMS.length;
    els.progressFill.style.width = (((i + 1) / DIMS.length) * 100) + "%";

    hideError();
    var field = document.getElementById("ocs-field-" + DIMS[i].id);
    if (field) field.focus({ preventScroll: false });
  }

  function saveCurrent() {
    var dim = DIMS[state.current];
    var field = document.getElementById("ocs-field-" + dim.id);
    state.values[dim.id] = field.value;
  }

  els.start.addEventListener("click", function () {
    els.intro.hidden = true;
    els.wizard.hidden = false;
    goToStep(0);
  });

  els.back.addEventListener("click", function () {
    saveCurrent();
    if (state.current > 0) goToStep(state.current - 1);
  });

  els.skip.addEventListener("click", function () {
    var dim = DIMS[state.current];
    var field = document.getElementById("ocs-field-" + dim.id);
    field.value = "";
    state.values[dim.id] = "";
    state.skipped[dim.id] = true;
    advance();
  });

  els.next.addEventListener("click", function () {
    var dim = DIMS[state.current];
    var field = document.getElementById("ocs-field-" + dim.id);
    var trimmed = field.value.trim();
    if (trimmed.length > 0 && trimmed.length < OCS.MIN_CHARS) {
      showError("That's a little short to score confidently \u2014 add more detail, or tap \u201cSkip this one.\u201d");
      return;
    }
    state.skipped[dim.id] = trimmed.length === 0;
    advance();
  });

  function advance() {
    saveCurrent();
    if (state.current < DIMS.length - 1) {
      goToStep(state.current + 1);
    } else {
      finish();
    }
  }

  els.form.addEventListener("submit", function (e) { e.preventDefault(); });

  /* ---------- finish + report ---------- */

  function finish() {
    var scan = OCS.runScan(state.values);
    if (scan.composite === null) {
      showError("Answer at least one question with real detail before scoring \u2014 even a single well-written answer is enough to start.");
      return;
    }
    renderReport(scan);
    els.wizard.hidden = true;
    els.report.hidden = false;
    els.report.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function toneColor(tone) {
    return { good: "var(--aqua-400)", ok: "var(--blue-500)", warn: "var(--amber-500)", bad: "var(--rose-500)" }[tone];
  }

  function renderReport(scan) {
    // composite
    var band = OCS.bandFor(scan.composite);
    els.composite.innerHTML =
      '<div class="ocs-composite-number" style="color:' + toneColor(band.tone) + '">' + scan.composite + '</div>' +
      '<div class="ocs-composite-meta">' +
        '<span class="ocs-band-pill" style="background:' + toneColor(band.tone) + '">' + band.label + '</span>' +
        '<span class="ocs-composite-label">Overall offer clarity</span>' +
      '</div>' +
      '<div class="ocs-signal" role="img" aria-label="Score by dimension">' +
        scan.results.map(function (r) {
          var h = r.score === null ? 6 : Math.max(6, Math.round((r.score / 100) * 48));
          var c = r.score === null ? "var(--slate-400)" : toneColor(OCS.bandFor(r.score).tone);
          return '<span class="ocs-signal-bar" style="height:' + h + 'px;background:' + c + '" title="' + r.dim.label + (r.score === null ? ': insufficient' : ': ' + r.score) + '"></span>';
        }).join("") +
      '</div>';

    // insufficient note
    if (scan.insufficientCount > 0) {
      els.insufficientNote.hidden = false;
      els.insufficientNote.textContent = scan.insufficientCount + " of " + DIMS.length + " question" + (scan.insufficientCount === 1 ? "" : "s") + " didn't have enough written to score confidently. The score above reflects the " + (DIMS.length - scan.insufficientCount) + " that did \u2014 fill in the rest and re-run for a complete read.";
    } else {
      els.insufficientNote.hidden = true;
    }

    // breakdown
    els.breakdown.innerHTML = scan.results.map(function (r) {
      var insufficient = r.analysis.status === "insufficient";
      var band2 = insufficient ? null : OCS.bandFor(r.score);
      return (
        '<div class="ocs-row">' +
          '<div class="ocs-row-top">' +
            '<span class="ocs-row-label">' + r.dim.label + '</span>' +
            (insufficient
              ? '<span class="ocs-band-pill ocs-band-pill--muted">Insufficient evidence</span>'
              : '<span class="ocs-band-pill" style="background:' + toneColor(band2.tone) + '">' + band2.label + ' \u00b7 ' + r.score + '</span>') +
          '</div>' +
          '<div class="ocs-row-bar-track"><div class="ocs-row-bar-fill" style="width:' + (insufficient ? 0 : r.score) + '%;background:' + (insufficient ? "var(--slate-400)" : toneColor(band2.tone)) + '"></div></div>' +
          '<p class="ocs-row-evidence">' + OCS.evidenceLine(r.analysis) + '</p>' +
        '</div>'
      );
    }).join("");

    // biggest leak
    if (scan.biggestLeak) {
      els.leak.innerHTML =
        '<p class="ocs-leak-kicker">Where you\u2019re leaking the most</p>' +
        '<h3 class="ocs-leak-title">' + scan.biggestLeak.dim.label + '</h3>' +
        '<p class="ocs-leak-body">' + scan.biggestLeak.dim.weak + '</p>';
      els.leak.hidden = false;
    } else {
      els.leak.hidden = true;
    }

    // fixes
    if (scan.leaks.length) {
      els.fixes.innerHTML =
        '<p class="ocs-fixes-kicker">Fix these first</p>' +
        '<ol class="ocs-fixes-list">' +
          scan.leaks.map(function (r, i) {
            return '<li><span class="ocs-fixes-index">' + (i + 1) + '</span><div><strong>' + r.dim.label + '.</strong> ' + r.dim.fix + '</div></li>';
          }).join("") +
        '</ol>';
    } else {
      els.fixes.innerHTML = "";
    }

    // method detail (built once, static)
    if (!els.methodDetail.dataset.built) {
      els.methodDetail.innerHTML =
        '<ul>' +
          '<li>Under ' + OCS.MIN_CHARS + ' characters: marked <em>insufficient evidence</em>, never scored.</li>' +
          '<li>Length: longer, more developed answers score higher, up to a point.</li>' +
          '<li>Concreteness: a number, price, percentage, or timeframe adds points.</li>' +
          '<li>Specificity: named tools, companies, roles, or terms add points.</li>' +
          '<li>Generic language: filler phrases like \u201cbest-in-class\u201d or \u201ccutting-edge\u201d subtract points.</li>' +
          '<li>The overall score is the average of every dimension that had enough to score.</li>' +
        '</ul>';
      els.methodDetail.dataset.built = "1";
    }
  }

  els.methodToggle.addEventListener("click", function (e) {
    e.preventDefault();
    els.methodDetail.hidden = !els.methodDetail.hidden;
  });

  els.restart.addEventListener("click", function () {
    state = { current: 0, values: {}, skipped: {} };
    els.steps.querySelectorAll("textarea").forEach(function (t) { t.value = ""; });
    els.steps.querySelectorAll(".ocs-hint").forEach(function (h) { h.classList.remove("ocs-hint-ok"); });
    els.report.hidden = true;
    els.intro.hidden = false;
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

})();
