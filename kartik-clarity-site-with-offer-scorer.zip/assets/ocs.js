/* =========================================================================
   OFFER CLARITY SCORER — deterministic, explainable, client-side.
   No network calls. No fabricated evidence. Every score traces back to
   a rule you can read below.
   ========================================================================= */

(function () {
  "use strict";

  /* ---------- 8 dimensions: config + copy ---------- */
  const DIMENSIONS = [
    {
      id: "audience",
      label: "Audience Clarity",
      prompt: "Who exactly is this offer for?",
      placeholder: "e.g. VP of Sales at 50\u2013200 person B2B SaaS companies doing $5M\u2013$30M ARR, selling mid-market.",
      weak: "The offer doesn\u2019t name a specific buyer \u2014 it reads as being for \u201canyone,\u201d so the right buyers have nothing to recognize themselves in. They scroll past without ever realizing it was written for them.",
      fix: "Name the exact role, company size or industry, and situation. Specific enough that a wrong-fit reader would immediately know it's not for them."
    },
    {
      id: "problem",
      label: "Problem Clarity",
      prompt: "What specific problem does this buyer have right now?",
      placeholder: "e.g. Reps spend 40% of their week manually updating CRM fields instead of selling, and pipeline data is too stale to trust for forecasting.",
      weak: "The problem is described in general terms rather than a specific, felt symptom. A buyer only leans in when they see their own pain named precisely \u2014 vague pain reads as marketing, not recognition.",
      fix: "Describe the problem the way the buyer would describe it to a colleague \u2014 specific, situational, and slightly uncomfortable to read if it's true of them."
    },
    {
      id: "outcome",
      label: "Outcome Clarity",
      prompt: "What outcome does the buyer get, in concrete terms?",
      placeholder: "e.g. Forecast accuracy improves from ~60% to 90%+ within one quarter, and reps get back 6\u20138 hours/week.",
      weak: "The outcome is stated as a general improvement rather than something concrete and checkable. Without a tangible result to picture, the buyer can't justify the offer internally.",
      fix: "State the outcome as something measurable or verifiable \u2014 a number, a before/after, or a timeframe \u2014 not just a direction of improvement."
    },
    {
      id: "mechanism",
      label: "Mechanism Clarity",
      prompt: "How do you actually produce that outcome?",
      placeholder: "e.g. We audit your CRM fields against your actual sales process, rebuild the pipeline stages around real buying signals, then train the team on the new stage-exit criteria.",
      weak: "It's unclear *how* the result happens \u2014 the offer asks the buyer to take the outcome on faith. Sophisticated buyers distrust outcomes with no visible mechanism behind them.",
      fix: "Name the actual steps or method \u2014 even briefly. A believable 3-step process beats an impressive but unexplained promise."
    },
    {
      id: "differentiation",
      label: "Differentiation",
      prompt: "Why this over the alternatives (competitors, or doing nothing)?",
      placeholder: "e.g. Unlike generic RevOps consultants, we only work inside the CRM you already use \u2014 no new tool to adopt, no 6-month implementation.",
      weak: "The reason to choose this over alternatives isn't concrete \u2014 it leans on general claims of quality rather than a specific point of difference a competitor couldn't also claim.",
      fix: "Name a specific way you're structurally different \u2014 in method, scope, speed, or focus \u2014 something a competitor's homepage couldn't copy-paste."
    },
    {
      id: "value",
      label: "Value Clarity",
      prompt: "How does the buyer understand what this is worth relative to what it costs?",
      placeholder: "e.g. Flat $8k engagement; the average client recovers that in the first month from recovered pipeline alone.",
      weak: "The value exchange isn't spelled out \u2014 the buyer is left to estimate on their own whether this is worth what it costs, which usually means they don't act.",
      fix: "Connect cost to value explicitly \u2014 price framed against what it saves, returns, or replaces. You don't need a number if you're not ready to share one, but you need the comparison."
    },
    {
      id: "proof",
      label: "Proof / Trust",
      prompt: "What evidence backs this up?",
      placeholder: "e.g. Used by 40+ B2B sales teams; case study: [Company] cut sales cycle by 22% in Q1 2026.",
      weak: "There's no independent evidence offered \u2014 results, client names, credentials, or specifics a skeptical buyer could check. Without proof, the strongest claims read as unverifiable.",
      fix: "Add something a skeptic could verify \u2014 a number, a named result, a credential, or a specific client outcome. Even one concrete proof point changes how the rest of the offer reads."
    },
    {
      id: "nextstep",
      label: "Next-Step Clarity",
      prompt: "What's the exact next action you want the buyer to take?",
      placeholder: "e.g. Book a 20-minute pipeline audit call \u2014 link below, no deck, no prep needed on your side.",
      weak: "The next step is vague or absent \u2014 the buyer has to figure out what to do next, and most won't bother. Interest that isn't given a single obvious action tends to evaporate.",
      fix: "Give one specific, low-friction action \u2014 not several options. Say exactly what happens if they take it."
    }
  ];

  const BANDS = [
    { min: 85, label: "Crystal Clear", tone: "good" },
    { min: 65, label: "Mostly Clear", tone: "ok" },
    { min: 40, label: "Foggy", tone: "warn" },
    { min: 0, label: "Leaking", tone: "bad" }
  ];

  const VAGUE_TERMS = [
    "best", "world-class", "cutting-edge", "cutting edge", "innovative", "revolutionary",
    "game-changing", "game changing", "leverage", "synergy", "solution", "solutions",
    "everyone", "everything", "anybody", "anyone", "all businesses", "unique",
    "amazing", "incredible", "unmatched", "unparalleled", "next-level", "next level",
    "state-of-the-art", "seamless", "robust", "holistic", "turnkey", "premier",
    "industry-leading", "top-tier", "top tier", "one-stop", "one stop"
  ];

  const MIN_CHARS = 15;

  /* ---------- scoring ---------- */

  function analyzeText(raw) {
    const text = (raw || "").trim();
    if (text.length < MIN_CHARS) {
      return { status: "insufficient" };
    }

    const words = text.split(/\s+/).filter(Boolean);
    const wordCount = words.length;
    const hasNumber = /\d/.test(text);

    const lower = text.toLowerCase();
    let vagueHits = 0;
    VAGUE_TERMS.forEach(function (term) {
      if (lower.indexOf(term) !== -1) vagueHits++;
    });

    // crude proxy for "named specifics": capitalized words that aren't the
    // first word of a sentence (company names, tool names, titles, proper nouns)
    const sentences = text.split(/(?<=[.!?])\s+/);
    let specificNouns = 0;
    sentences.forEach(function (s) {
      const w = s.trim().split(/\s+/);
      for (let i = 1; i < w.length; i++) {
        const clean = w[i].replace(/[^A-Za-z]/g, "");
        if (clean.length > 1 && clean === clean[0].toUpperCase() + clean.slice(1) && clean !== clean.toUpperCase()) {
          specificNouns++;
        }
      }
    });

    let score = 0;
    score += Math.min(35, (wordCount / 28) * 35);           // length adequacy
    score += hasNumber ? 15 : 0;                              // concrete number present
    score += Math.min(20, specificNouns * 7);                 // named specifics
    score += 35;                                              // base credit for a non-empty, substantive answer
    score -= Math.min(30, vagueHits * 6);                     // vagueness penalty

    score = Math.max(0, Math.min(100, Math.round(score)));

    return {
      status: "scored",
      score: score,
      wordCount: wordCount,
      hasNumber: hasNumber,
      vagueHits: vagueHits,
      specificNouns: specificNouns
    };
  }

  function bandFor(score) {
    for (let i = 0; i < BANDS.length; i++) {
      if (score >= BANDS[i].min) return BANDS[i];
    }
    return BANDS[BANDS.length - 1];
  }

  function evidenceLine(a) {
    if (a.status === "insufficient") return "Not enough written to evaluate \u2014 add a few more specifics.";
    const bits = [];
    bits.push(a.wordCount + " word" + (a.wordCount === 1 ? "" : "s") + " provided");
    bits.push(a.hasNumber ? "includes a concrete number" : "no concrete number given");
    bits.push(
      a.vagueHits === 0
        ? "no generic filler phrases detected"
        : a.vagueHits + " generic filler phrase" + (a.vagueHits === 1 ? "" : "s") + " detected"
    );
    if (a.specificNouns > 0) {
      bits.push(a.specificNouns + " specific named term" + (a.specificNouns === 1 ? "" : "s") + " found");
    }
    return bits.join(" \u00b7 ");
  }

  /* ---------- public: run the whole scan ---------- */

  function runScan(inputs) {
    const results = DIMENSIONS.map(function (dim) {
      const a = analyzeText(inputs[dim.id] || "");
      return {
        dim: dim,
        analysis: a,
        score: a.status === "scored" ? a.score : null
      };
    });

    const scored = results.filter(function (r) { return r.score !== null; });
    const insufficientCount = results.length - scored.length;

    const composite = scored.length
      ? Math.round(scored.reduce(function (sum, r) { return sum + r.score; }, 0) / scored.length)
      : null;

    const ranked = scored.slice().sort(function (a, b) { return a.score - b.score; });
    const leaks = ranked.slice(0, 3);

    return {
      results: results,
      composite: composite,
      insufficientCount: insufficientCount,
      leaks: leaks,
      biggestLeak: ranked[0] || null
    };
  }

  const api = {
    DIMENSIONS: DIMENSIONS,
    BANDS: BANDS,
    analyzeText: analyzeText,
    bandFor: bandFor,
    evidenceLine: evidenceLine,
    runScan: runScan,
    MIN_CHARS: MIN_CHARS
  };

  var root = typeof window !== "undefined" ? window : (typeof global !== "undefined" ? global : this);
  root.OfferClarityScorer = api;
  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
})();
